package com.example.bilingualkeyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class BilingualImeService : InputMethodService() {
    private var russian = false
    private var shifted = false
    private lateinit var keyboard: LinearLayout

    private val englishRows = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("⇧","z","x","c","v","b","n","m","⌫"),
        listOf("?123","🌐",",","space",".","↵")
    )
    private val russianRows = listOf(
        listOf("й","ц","у","к","е","н","г","ш","щ","з","х"),
        listOf("ф","ы","в","а","п","р","о","л","д","ж","э"),
        listOf("⇧","я","ч","с","м","и","т","ь","б","ю","⌫"),
        listOf("?123","🌐",",","space",".","↵")
    )

    override fun onCreateInputView(): View {
        keyboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            setBackgroundColor(Color.rgb(28, 30, 35))
        }
        renderKeyboard()
        return keyboard
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shifted = false
        if (::keyboard.isInitialized) renderKeyboard()
    }

    private fun renderKeyboard() {
        keyboard.removeAllViews()
        val rows = if (russian) russianRows else englishRows
        rows.forEachIndexed { rowIndex, keys ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            keys.forEach { key ->
                val label = when (key) {
                    "space" -> "English / Русский"
                    else -> if (shifted && key.length == 1) key.uppercase() else key
                }
                val button = Button(this).apply {
                    text = label
                    textSize = if (key == "space") 12f else 17f
                    setTextColor(Color.WHITE)
                    typeface = Typeface.DEFAULT_BOLD
                    isAllCaps = false
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = 0
                    minimumHeight = 0
                    setPadding(dp(2), 0, dp(2), 0)
                    background = rounded(if (key in listOf("⇧","⌫","↵","?123","🌐")) 0xFF505866.toInt() else 0xFF3A3F49.toInt())
                    setOnClickListener { handleKey(key) }
                }
                val weight = when (key) {
                    "space" -> 4f
                    "?123", "🌐", "⇧", "⌫", "↵" -> 1.35f
                    else -> 1f
                }
                row.addView(button, LinearLayout.LayoutParams(0, dp(48), weight).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
            keyboard.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⇧" -> { shifted = !shifted; renderKeyboard() }
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            "space" -> ic.commitText(" ", 1)
            "🌐" -> { russian = !russian; shifted = false; renderKeyboard() }
            "?123" -> {
                // Symbols are intentionally kept simple; switch back to letters with this key.
                russian = false
                shifted = !shifted
                renderKeyboard()
            }
            else -> {
                val out = if (shifted) key.uppercase() else key
                ic.commitText(out, 1)
                if (shifted) { shifted = false; renderKeyboard() }
            }
        }
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(7).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
