# Bilingual Keyboard (Android)

A starter Android Input Method Editor (IME) with English QWERTY and standard Russian ЙЦУКЕН layouts.

## Build and install
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android phone.
5. Open **Settings > General management > Keyboard list and default** (Samsung).
6. Enable **Bilingual Keyboard**, then choose it under **Default keyboard**.

## Use
- Tap **🌐** to switch between English and Russian.
- Tap **⇧** for uppercase.
- **⌫** deletes, **↵** enters, and the wide space key inserts a space.

This is a basic starter keyboard, not a full Gboard replacement: it does not include predictive text, autocorrect, swipe typing, a full symbol page, or emoji picker. It types ordinary Unicode text and does not alter app moderation or filtering.

The keyboard processes keystrokes locally and does not request internet permission.
